package com.ght.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ght.model.PersonalDetails;

public interface PersonalDetailsRepository extends JpaRepository<PersonalDetails, Long>{

}
